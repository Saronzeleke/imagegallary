function openModal(src, alt) {
    const modal = document.getElementById("modal");
    const modalImage = document.getElementById("modalImage");
    const captionText = document.getElementById("caption");

    modal.style.display = "block";
    modalImage.src = src;
    captionText.innerHTML = alt; // set the caption to the image alt text
}

function closeModal() {
    const modal = document.getElementById("modal");
    modal.style.display = "none";
}
document.getElementById('uploadForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent form submission

    const fileInput = document.getElementById('imageInput');
    
    // Check if a file is selected
    if (fileInput.files.length === 0) {
        alert('Please select an image to upload.');
        return;
    }

    const file = fileInput.files[0];
    const reader = new FileReader();

    reader.onload = function(e) {
        displayImage(e.target.result);
    };

    reader.readAsDataURL(file); // Convert the file to a data URL
});

function displayImage(imageUrl) {
    const gallery = document.getElementById('gallery');
    const img = document.createElement('img');
    img.src = imageUrl; // Use the data URL as the source
    img.className = 'thumbnail'; // Add class for styling
    gallery.appendChild(img); // Add the image to the gallery
}